package com.example.overlaykit;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/** Общие элементы оформления: чёрный, белый и жёлтый. Только визуальные компоненты. */
final class Ui {
    private Ui() {}

    static final int BG = 0xFF0B0B0B;
    static final int PANEL = 0xF2121212;
    static final int CARD = 0xFF1C1C1C;
    static final int OFF = 0xFF3A3A3A;
    static final int WHITE = 0xFFFFFFFF;
    static final int MUTED = 0xFF9A9A9A;
    static final int YELLOW = 0xFFFFD60A;

    interface BoolCb { void on(boolean v); }
    interface IntCb { void on(int v); }

    static int dp(Context c, float v) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics());
    }

    static GradientDrawable rect(Context c, int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    static TextView text(Context c, String t, float sp, int color, boolean bold) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        return v;
    }

    /** Лёгкое сжатие при нажатии. Событие не поглощается, клик работает как обычно. */
    static void pressFx(View v) {
        v.setOnTouchListener((view, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                    break;
                default:
                    break;
            }
            return false;
        });
    }

    static TextView button(Context c, String t, int accent, boolean filled) {
        TextView b = text(c, t, 14, filled ? BG : accent, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12));
        GradientDrawable d = rect(c, filled ? accent : CARD, 12);
        if (!filled) d.setStroke(dp(c, 1), accent);
        b.setBackground(d);
        b.setClickable(true);
        pressFx(b);
        return b;
    }

    /** Строка с переключателем. Переключатель только меняет вид и вызывает callback. */
    static View toggleRow(Context c, String label, boolean init, int accent,
                          boolean animate, BoolCb cb) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10));
        row.setBackground(rect(c, CARD, 12));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = dp(c, 6);
        row.setLayoutParams(rlp);

        TextView t = text(c, label, 14, WHITE, false);
        row.addView(t, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        final FrameLayout pill = new FrameLayout(c);
        final GradientDrawable pillBg = rect(c, init ? accent : OFF, 14);
        pill.setBackground(pillBg);
        final View knob = new View(c);
        knob.setBackground(rect(c, init ? BG : WHITE, 10));
        FrameLayout.LayoutParams klp = new FrameLayout.LayoutParams(dp(c, 20), dp(c, 20));
        klp.gravity = Gravity.CENTER_VERTICAL;
        klp.leftMargin = dp(c, 4);
        pill.addView(knob, klp);
        row.addView(pill, new LinearLayout.LayoutParams(dp(c, 48), dp(c, 28)));
        knob.setTranslationX(init ? dp(c, 20) : 0);

        final boolean[] on = {init};
        row.setClickable(true);
        row.setOnClickListener(v -> {
            on[0] = !on[0];
            float target = on[0] ? dp(c, 20) : 0;
            int from = on[0] ? OFF : accent;
            int to = on[0] ? accent : OFF;
            ((GradientDrawable) knob.getBackground()).setColor(on[0] ? BG : WHITE);
            if (animate) {
                knob.animate().translationX(target).setDuration(160).start();
                ValueAnimator va = ValueAnimator.ofObject(new ArgbEvaluator(), from, to);
                va.setDuration(160);
                va.addUpdateListener(a -> pillBg.setColor((Integer) a.getAnimatedValue()));
                va.start();
            } else {
                knob.setTranslationX(target);
                pillBg.setColor(to);
            }
            if (cb != null) cb.on(on[0]);
        });
        pressFx(row);
        return row;
    }

    /** Строка с ползунком. */
    static View sliderRow(Context c, String label, int min, int max, int init,
                          String suffix, int accent, IntCb cb) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 6));
        box.setBackground(rect(c, CARD, 12));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(c, 6);
        box.setLayoutParams(blp);

        LinearLayout top = new LinearLayout(c);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.addView(text(c, label, 14, WHITE, false), new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView value = text(c, init + suffix, 13, accent, true);
        top.addView(value);
        box.addView(top);

        SeekBar bar = new SeekBar(c);
        bar.setMax(max - min);
        bar.setProgress(init - min);
        bar.setProgressTintList(ColorStateList.valueOf(accent));
        bar.setThumbTintList(ColorStateList.valueOf(accent));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(OFF));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                int v = p + min;
                value.setText(v + suffix);
                if (fromUser && cb != null) cb.on(v);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        box.addView(bar);
        return box;
    }

    /** Ряд переключаемых вариантов (сегментный выбор). */
    static View chips(Context c, String[] options, int selected, int accent, IntCb cb) {
        final LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = dp(c, 6);
        row.setLayoutParams(rlp);
        final TextView[] items = new TextView[options.length];
        for (int i = 0; i < options.length; i++) {
            final int index = i;
            TextView t = text(c, options[i], 13, i == selected ? BG : WHITE, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(c, 6), dp(c, 9), dp(c, 6), dp(c, 9));
            t.setBackground(rect(c, i == selected ? accent : CARD, 10));
            t.setClickable(true);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.leftMargin = dp(c, 6);
            row.addView(t, lp);
            items[i] = t;
            t.setOnClickListener(v -> {
                for (int k = 0; k < items.length; k++) {
                    boolean sel = k == index;
                    items[k].setTextColor(sel ? BG : WHITE);
                    ((GradientDrawable) items[k].getBackground()).setColor(sel ? accent : CARD);
                }
                if (cb != null) cb.on(index);
            });
        }
        return row;
    }

    static View sectionTitle(Context c, String t) {
        TextView v = text(c, t.toUpperCase(), 11, MUTED, true);
        v.setLetterSpacing(0.1f);
        v.setPadding(dp(c, 2), dp(c, 12), 0, 0);
        return v;
    }
}
