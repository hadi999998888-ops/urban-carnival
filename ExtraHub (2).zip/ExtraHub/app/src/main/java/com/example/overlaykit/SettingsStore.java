package com.example.overlaykit;

import android.content.Context;
import android.content.SharedPreferences;

/** Хранение настроек через SharedPreferences. */
public final class SettingsStore {
    private static final String FILE = "overlay_settings";
    private static final String KEY_OPACITY = "opacity";       // 20..100
    private static final String KEY_X = "pos_x";
    private static final String KEY_Y = "pos_y";
    private static final String KEY_REMEMBER = "remember_pos";
    private static final String KEY_ENABLED = "overlay_enabled";
    private static final String KEY_ANIM = "animations";
    private static final String KEY_SIZE = "panel_size";       // 0..2
    private static final String KEY_ACCENT = "accent";         // 0 жёлтый, 1 белый

    private final SharedPreferences prefs;

    public SettingsStore(Context context) {
        prefs = context.getApplicationContext()
                .getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public int getOpacityPercent() { return prefs.getInt(KEY_OPACITY, 85); }
    public void setOpacityPercent(int v) {
        prefs.edit().putInt(KEY_OPACITY, Math.max(20, Math.min(100, v))).apply();
    }

    public boolean isRememberPosition() { return prefs.getBoolean(KEY_REMEMBER, true); }
    public void setRememberPosition(boolean v) { prefs.edit().putBoolean(KEY_REMEMBER, v).apply(); }

    public boolean isOverlayEnabled() { return prefs.getBoolean(KEY_ENABLED, false); }
    public void setOverlayEnabled(boolean v) { prefs.edit().putBoolean(KEY_ENABLED, v).apply(); }

    public int getX() { return prefs.getInt(KEY_X, 40); }
    public int getY() { return prefs.getInt(KEY_Y, 200); }
    public void setPosition(int x, int y) { prefs.edit().putInt(KEY_X, x).putInt(KEY_Y, y).apply(); }

    public boolean isAnimations() { return prefs.getBoolean(KEY_ANIM, true); }
    public void setAnimations(boolean v) { prefs.edit().putBoolean(KEY_ANIM, v).apply(); }

    public int getSize() { return prefs.getInt(KEY_SIZE, 1); }
    public void setSize(int v) { prefs.edit().putInt(KEY_SIZE, Math.max(0, Math.min(2, v))).apply(); }

    public int getAccent() { return prefs.getInt(KEY_ACCENT, 0); }
    public void setAccent(int v) { prefs.edit().putInt(KEY_ACCENT, v == 1 ? 1 : 0).apply(); }
    public int getAccentColor() { return getAccent() == 1 ? Ui.WHITE : Ui.YELLOW; }
}
