package com.example.overlaykit;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Outline;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Главный экран Extra Hub: разрешение, запуск панели и ссылки на каналы. */
public class MainActivity extends Activity {
    private static final int REQ_NOTIF = 100;

    private static final String[][] LINKS = {
            {"Канал ExtraCheatStanddof2", "https://t.me/ExtraCheatStanddof2"},
            {"Канал 2", "https://t.me/+lyHMe0599OtjYjEy"},
            {"Канал 3", "https://t.me/+ndJdcTlMwD1lNjRi"},
    };

    private SettingsStore settings;
    private TextView permissionStatus;
    private TextView toggleButton;
    private LinearLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        settings = new SettingsStore(this);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        setContentView(buildUi());
        playEntrance();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshState();
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private LinearLayout.LayoutParams full(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topDp);
        return lp;
    }

    private View buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22), dp(48), dp(22), dp(32));

        ImageView logo = new ImageView(this);
        int res = getResources().getIdentifier("logo", "drawable", getPackageName());
        logo.setImageResource(res != 0 ? res : R.drawable.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logo.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(22));
            }
        });
        logo.setClipToOutline(true);
        root.addView(logo, new LinearLayout.LayoutParams(dp(96), dp(96)));

        TextView title = Ui.text(this, "Extra Hub", 30, Ui.WHITE, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, full(16));

        TextView sub = Ui.text(this, "ДЕМО-МАКЕТ ИНТЕРФЕЙСА", 12, Ui.YELLOW, true);
        sub.setGravity(Gravity.CENTER);
        sub.setLetterSpacing(0.15f);
        root.addView(sub, full(4));

        TextView note = Ui.text(this,
                "Плавающее меню с вкладками. Кнопки ESP, Aim, Wallhack, Air Jump и скины "
                        + "только показывают оформление и ничего не делают в играх. "
                        + "Рабочие только настройки самого меню.",
                13, Ui.MUTED, false);
        note.setGravity(Gravity.CENTER);
        root.addView(note, full(12));

        permissionStatus = Ui.text(this, "", 14, Ui.WHITE, true);
        permissionStatus.setPadding(dp(16), dp(14), dp(16), dp(14));
        permissionStatus.setBackground(Ui.rect(this, Ui.CARD, 14));
        root.addView(permissionStatus, full(24));

        TextView grant = Ui.button(this, "Выдать разрешение «Поверх других приложений»",
                Ui.YELLOW, false);
        grant.setOnClickListener(v -> openOverlayPermissionScreen());
        root.addView(grant, full(10));

        toggleButton = Ui.button(this, "Запустить меню", Ui.YELLOW, true);
        toggleButton.setOnClickListener(v -> toggleOverlay());
        root.addView(toggleButton, full(10));

        root.addView(Ui.sectionTitle(this, "Наши каналы"), full(22));
        for (String[] l : LINKS) {
            final String url = l[1];
            TextView b = Ui.button(this, l[0], Ui.WHITE, false);
            b.setOnClickListener(v -> openUrl(url));
            root.addView(b, full(8));
        }

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Ui.BG);
        scroll.setFillViewport(true);
        scroll.addView(root);
        return scroll;
    }

    /** Плавное поочерёдное появление элементов. */
    private void playEntrance() {
        for (int i = 0; i < root.getChildCount(); i++) {
            View v = root.getChildAt(i);
            v.setAlpha(0f);
            v.setTranslationY(dp(24));
            v.animate().alpha(1f).translationY(0f)
                    .setStartDelay(60L * i).setDuration(380).start();
        }
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshState() {
        boolean granted = Settings.canDrawOverlays(this);
        permissionStatus.setText(granted
                ? "Разрешение выдано"
                : "Разрешение «Поверх других приложений» не выдано");
        permissionStatus.setTextColor(granted ? Ui.YELLOW : Ui.WHITE);
        if (!granted) settings.setOverlayEnabled(false);
        toggleButton.setText(settings.isOverlayEnabled() ? "Остановить меню" : "Запустить меню");
    }

    private void openOverlayPermissionScreen() {
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }

    private void toggleOverlay() {
        if (settings.isOverlayEnabled()) {
            Intent stop = new Intent(this, OverlayService.class);
            stop.setAction(OverlayService.ACTION_STOP);
            startService(stop);
            settings.setOverlayEnabled(false);
            refreshState();
            return;
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала выдайте разрешение", Toast.LENGTH_SHORT).show();
            openOverlayPermissionScreen();
            return;
        }

        // На Android 13+ без разрешения на уведомления меню всё равно работает,
        // но уведомление службы не будет видно, поэтому просим его заранее.
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        startOverlay();
    }

    private void startOverlay() {
        Intent start = new Intent(this, OverlayService.class);
        start.setAction(OverlayService.ACTION_START);
        startForegroundService(start);
        settings.setOverlayEnabled(true);
        refreshState();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_NOTIF) {
            // Запускаем в любом случае: отказ влияет только на видимость уведомления.
            startOverlay();
        }
    }
}
