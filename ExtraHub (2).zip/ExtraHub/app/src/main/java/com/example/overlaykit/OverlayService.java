package com.example.overlaykit;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Outline;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.HashMap;

/**
 * Плавающее меню Extra Hub. Это ДЕМО-ИНТЕРФЕЙС: переключатели и ползунки только
 * меняют внешний вид. Никаких данных других приложений сервис не читает и ничего
 * поверх них не рисует. Рабочие только настройки самого меню (вкладка «Настройки»).
 */
public class OverlayService extends Service {
    public static final String ACTION_START = "com.example.overlaykit.START";
    public static final String ACTION_STOP = "com.example.overlaykit.STOP";
    private static final String CHANNEL_ID = "overlay_channel";
    private static final int NOTIF_ID = 1;

    private static final String[] TAB_NAMES = {"ESP", "Aim", "Wallhack", "Air Jump", "Скины", "Настройки"};
    private static final int[] WIDTHS_DP = {270, 310, 350};
    private static final String[] WEAPONS = {"AK-47", "M4", "AWP", "Deagle", "Нож"};
    private static final String[] SKINS = {"Gold Rush", "Carbon", "Neon Wave", "Camo", "Dragon", "Stealth"};

    private WindowManager windowManager;
    private View panel;
    private LinearLayout content;
    private ScrollView scroll;
    private LinearLayout body;
    private TextView[] tabViews;
    private WindowManager.LayoutParams params;
    private SettingsStore settings;

    private int tab = 0;
    private boolean collapsed = false;
    private int accent = Ui.YELLOW;
    private boolean anim = true;

    /** Состояние демо-переключателей на время работы службы. */
    private final HashMap<String, Integer> state = new HashMap<>();

    @Override
    public void onCreate() {
        super.onCreate();
        settings = new SettingsStore(this);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelfAndCleanup();
            return START_NOT_STICKY;
        }

        // Без разрешения окно добавить нельзя: останавливаемся без падения.
        if (!Settings.canDrawOverlays(this)) {
            settings.setOverlayEnabled(false);
            stopSelf();
            return START_NOT_STICKY;
        }

        startInForeground();
        if (panel == null) {
            addPanel(true);
        }
        settings.setOverlayEnabled(true);
        return START_STICKY;
    }

    private void startInForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Extra Hub", NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(channel);

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Extra Hub активен")
                .setContentText("Нажмите, чтобы открыть приложение")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private int get(String key, int def) {
        Integer v = state.get(key);
        return v == null ? def : v;
    }

    // ---------------------------------------------------------------- панель

    private void addPanel(boolean animateIn) {
        accent = settings.getAccentColor();
        anim = settings.isAnimations();

        if (params == null) {
            params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.START;
            if (settings.isRememberPosition()) {
                params.x = settings.getX();
                params.y = settings.getY();
            } else {
                params.x = 40;
                params.y = 200;
            }
        }
        params.width = dp(WIDTHS_DP[settings.getSize()]);

        panel = buildPanel();
        try {
            windowManager.addView(panel, params);
        } catch (RuntimeException ex) {
            // Например, разрешение отозвано между проверкой и добавлением окна.
            panel = null;
            settings.setOverlayEnabled(false);
            stopSelf();
            return;
        }

        if (animateIn && anim) {
            float target = settings.getOpacityPercent() / 100f;
            panel.setAlpha(0f);
            panel.setScaleX(0.9f);
            panel.setScaleY(0.9f);
            panel.animate().alpha(target).scaleX(1f).scaleY(1f).setDuration(260).start();
        }
    }

    private void rebuildPanel() {
        removePanel();
        addPanel(false);
    }

    private View buildPanel() {
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = Ui.rect(this, Ui.PANEL, 18);
        bg.setStroke(dp(1), (accent & 0x00FFFFFF) | 0x66000000);
        root.setBackground(bg);
        root.setAlpha(settings.getOpacityPercent() / 100f);

        root.addView(buildHeader());

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);

        HorizontalScrollView tabScroll = new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setPadding(dp(10), 0, dp(10), dp(4));
        tabViews = new TextView[TAB_NAMES.length];
        for (int i = 0; i < TAB_NAMES.length; i++) {
            final int index = i;
            TextView t = Ui.text(this, TAB_NAMES[i], 13, Ui.WHITE, true);
            t.setPadding(dp(12), dp(8), dp(12), dp(8));
            t.setClickable(true);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(6);
            tabRow.addView(t, lp);
            t.setOnClickListener(v -> {
                if (tab != index) {
                    tab = index;
                    scroll.scrollTo(0, 0);
                    renderTab(true);
                }
            });
            Ui.pressFx(t);
            tabViews[i] = t;
        }
        tabScroll.addView(tabRow);
        body.addView(tabScroll);

        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), 0, dp(12), dp(12));
        scroll.addView(content);
        body.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(270)));

        root.addView(body);
        body.setVisibility(collapsed ? View.GONE : View.VISIBLE);

        renderTab(false);
        return root;
    }

    private View buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(12), dp(10), dp(8), dp(8));

        // Логотип рядом с ником. Если добавлен drawable/logo, берём его.
        ImageView logo = new ImageView(this);
        int res = getResources().getIdentifier("logo", "drawable", getPackageName());
        logo.setImageResource(res != 0 ? res : R.drawable.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logo.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(10));
            }
        });
        logo.setClipToOutline(true);
        header.addView(logo, new LinearLayout.LayoutParams(dp(40), dp(40)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(Ui.text(this, "Extra Hub", 17, Ui.WHITE, true));
        titles.addView(Ui.text(this, "Player  •  ДЕМО, функции не работают", 10, accent, false));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tlp.leftMargin = dp(10);
        header.addView(titles, tlp);

        TextView collapse = Ui.text(this, collapsed ? "+" : "—", 18, Ui.WHITE, true);
        collapse.setGravity(Gravity.CENTER);
        collapse.setClickable(true);
        collapse.setOnClickListener(v -> {
            collapsed = !collapsed;
            ((TextView) v).setText(collapsed ? "+" : "—");
            if (collapsed) {
                body.setVisibility(View.GONE);
            } else {
                body.setVisibility(View.VISIBLE);
                if (anim) {
                    body.setAlpha(0f);
                    body.animate().alpha(1f).setDuration(200).start();
                }
            }
        });
        header.addView(collapse, new LinearLayout.LayoutParams(dp(36), dp(36)));

        TextView close = Ui.text(this, "✕", 16, Ui.WHITE, true);
        close.setGravity(Gravity.CENTER);
        close.setClickable(true);
        close.setOnClickListener(v -> stopSelfAndCleanup());
        header.addView(close, new LinearLayout.LayoutParams(dp(36), dp(36)));

        // Перетаскивание панели за шапку.
        header.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x;
                        startY = params.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = startX + (int) (e.getRawX() - touchX);
                        params.y = startY + (int) (e.getRawY() - touchY);
                        if (panel != null) windowManager.updateViewLayout(panel, params);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (settings.isRememberPosition()) {
                            settings.setPosition(params.x, params.y);
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
        return header;
    }

    // ---------------------------------------------------------------- вкладки

    private void renderTab(boolean animate) {
        for (int i = 0; i < tabViews.length; i++) {
            boolean sel = i == tab;
            tabViews[i].setTextColor(sel ? Ui.BG : Ui.WHITE);
            tabViews[i].setBackground(Ui.rect(this, sel ? accent : Ui.CARD, 10));
        }

        content.removeAllViews();
        switch (tab) {
            case 0: buildEsp(); break;
            case 1: buildAim(); break;
            case 2: buildWall(); break;
            case 3: buildJump(); break;
            case 4: buildSkins(); break;
            default: buildSettings(); break;
        }

        if (animate && anim) {
            content.setAlpha(0f);
            content.setTranslationY(dp(10));
            content.animate().alpha(1f).translationY(0f).setDuration(220).start();
        }
    }

    private void toggle(String key, String label) {
        content.addView(Ui.toggleRow(this, label, get(key, 0) == 1, accent, anim,
                v -> state.put(key, v ? 1 : 0)));
    }

    private void slider(String key, String label, int min, int max, int def, String suffix) {
        content.addView(Ui.sliderRow(this, label, min, max, get(key, def), suffix, accent,
                v -> state.put(key, v)));
    }

    private void chips(String key, String[] options, int def) {
        content.addView(Ui.chips(this, options, get(key, def), accent, i -> state.put(key, i)));
    }

    private void note(String text) {
        TextView t = Ui.text(this, text, 11, Ui.MUTED, false);
        t.setPadding(dp(2), dp(10), dp(2), 0);
        content.addView(t);
    }

    private void buildEsp() {
        toggle("esp_on", "ESP");
        toggle("esp_box", "Box");
        toggle("esp_lines", "Линии");
        toggle("esp_hp", "Здоровье");
        toggle("esp_names", "Имена");
        slider("esp_dist", "Дальность", 50, 500, 250, " м");
        note("Демо: переключатели меняют только вид.");
    }

    private void buildAim() {
        toggle("aim_on", "Aim");
        toggle("aim_fov_show", "Показывать FOV");
        slider("aim_fov", "FOV", 1, 180, 60, "°");
        slider("aim_smooth", "Плавность", 1, 100, 40, "%");
        content.addView(Ui.sectionTitle(this, "Цель"));
        chips("aim_target", new String[]{"Голова", "Тело", "Ближайшая"}, 0);
        note("Демо: переключатели меняют только вид.");
    }

    private void buildWall() {
        toggle("wall_on", "Wallhack");
        toggle("wall_outline", "Контуры");
        slider("wall_alpha", "Прозрачность", 10, 100, 70, "%");
        content.addView(Ui.sectionTitle(this, "Цвет"));
        chips("wall_color", new String[]{"Жёлтый", "Белый", "Красный"}, 0);
        note("Демо: переключатели меняют только вид.");
    }

    private void buildJump() {
        toggle("jump_on", "Air Jump");
        toggle("jump_inf", "Бесконечные прыжки");
        slider("jump_h", "Высота", 1, 10, 3, "x");
        note("Демо: переключатели меняют только вид.");
    }

    private void buildSkins() {
        content.addView(Ui.sectionTitle(this, "Оружие"));
        content.addView(Ui.chips(this, WEAPONS, get("skin_weapon", 0), accent, i -> {
            state.put("skin_weapon", i);
            panel.post(() -> { renderTab(true); });
        }));
        content.addView(Ui.sectionTitle(this, "Скины (примеры)"));

        final int weapon = get("skin_weapon", 0);
        final String key = "skin_sel_" + weapon;
        final int selected = get(key, -1);
        for (int i = 0; i < SKINS.length; i++) {
            final int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(8), dp(8), dp(8));
            row.setBackground(Ui.rect(this, Ui.CARD, 12));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = dp(6);
            row.setLayoutParams(rlp);

            row.addView(Ui.text(this, WEAPONS[weapon] + " | " + SKINS[i], 13, Ui.WHITE, false),
                    new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            boolean sel = index == selected;
            TextView btn = Ui.button(this, sel ? "Выбран" : "Выбрать", accent, sel);
            btn.setTextSize(12);
            btn.setPadding(dp(12), dp(7), dp(12), dp(7));
            btn.setOnClickListener(v -> {
                state.put(key, index);
                panel.post(() -> { renderTab(false); });
            });
            row.addView(btn);
            content.addView(row);
        }
        note("Демо: названия примерные, скины не применяются.");
    }

    private void buildSettings() {
        content.addView(Ui.sectionTitle(this, "Внешний вид меню"));
        content.addView(Ui.sliderRow(this, "Прозрачность", 20, 100,
                settings.getOpacityPercent(), "%", accent, v -> {
                    settings.setOpacityPercent(v);
                    if (panel != null) panel.setAlpha(v / 100f);
                }));

        content.addView(Ui.sectionTitle(this, "Размер меню"));
        content.addView(Ui.chips(this, new String[]{"Мал.", "Сред.", "Бол."},
                settings.getSize(), accent, i -> {
                    settings.setSize(i);
                    panel.post(this::rebuildPanel);
                }));

        content.addView(Ui.sectionTitle(this, "Цвет акцента"));
        content.addView(Ui.chips(this, new String[]{"Жёлтый", "Белый"},
                settings.getAccent(), accent, i -> {
                    settings.setAccent(i);
                    panel.post(this::rebuildPanel);
                }));

        content.addView(Ui.sectionTitle(this, "Поведение"));
        content.addView(Ui.toggleRow(this, "Запоминать положение",
                settings.isRememberPosition(), accent, anim, v -> {
                    settings.setRememberPosition(v);
                    if (v && params != null) settings.setPosition(params.x, params.y);
                }));
        content.addView(Ui.toggleRow(this, "Анимации",
                settings.isAnimations(), accent, anim, v -> {
                    settings.setAnimations(v);
                    anim = v;
                }));

        TextView reset = Ui.button(this, "Сбросить положение", accent, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(12);
        reset.setLayoutParams(lp);
        reset.setOnClickListener(v -> {
            params.x = 40;
            params.y = 200;
            settings.setPosition(40, 200);
            if (panel != null) windowManager.updateViewLayout(panel, params);
        });
        content.addView(reset);
    }

    // ---------------------------------------------------------------- завершение

    private void stopSelfAndCleanup() {
        removePanel();
        settings.setOverlayEnabled(false);
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void removePanel() {
        if (panel != null) {
            try {
                windowManager.removeView(panel);
            } catch (IllegalArgumentException ignored) {
                // окно уже удалено
            }
            panel = null;
        }
    }

    @Override
    public void onDestroy() {
        removePanel();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
